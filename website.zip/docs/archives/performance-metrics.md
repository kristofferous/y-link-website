# Archived performance metrics (removed from public site)

- Date of removal: 2025-12-13
- Timing Accuracy: ±2ms
- Sequence Stability: 99.7%
- Uptime (Pilot): 99.2%
- Note: Measured across 6 pilot venues over 3 months.
