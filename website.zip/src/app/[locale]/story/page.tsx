import { notFound } from "next/navigation";

export default function StoryArchivePage() {
  // Denne historien er arkivert og ikke lenger tilgjengelig
  notFound();
}
